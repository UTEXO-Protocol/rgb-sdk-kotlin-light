#!/usr/bin/env bash
# Builds the library, generates its Python bindings into a temporary directory
# and runs scripts/ffi-smoke.py against tests/fixtures/ffi-smoke.json.
set -euo pipefail

CORE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${CORE_DIR}"

case "$(uname -s)" in
  Darwin) LIBRARY="target/debug/libutexo_rgb_verifier.dylib" ;;
  *) LIBRARY="target/debug/libutexo_rgb_verifier.so" ;;
esac

cargo build --locked --features bindgen --bin uniffi-bindgen
cargo build --locked --lib

OUT_DIR="$(mktemp -d)"
trap 'rm -rf "${OUT_DIR}"' EXIT

target/debug/uniffi-bindgen generate \
  --config uniffi-bindgen.toml \
  "${LIBRARY}" \
  --language python \
  --out-dir "${OUT_DIR}"
cp "${LIBRARY}" "${OUT_DIR}/"

python3 -I scripts/ffi-smoke.py "${OUT_DIR}" tests/fixtures/ffi-smoke.json
