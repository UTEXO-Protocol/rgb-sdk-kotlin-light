#!/usr/bin/env bash
# Builds release libraries for the Android ABIs the Kotlin SDK ships.
#
# Usage: scripts/build-android.sh [out-dir]   (default: target/android/jniLibs)
# Writes <out-dir>/{arm64-v8a,armeabi-v7a,x86_64}/libutexo_rgb_verifier.so.
# Needs cargo-ndk and an NDK (ANDROID_NDK_HOME, or the newest under
# $ANDROID_HOME/ndk). Minimum API 24, matching the local signer.
set -euo pipefail

CORE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${CORE_DIR}"
OUT_DIR="${1:-target/android/jniLibs}"
ABIS=(arm64-v8a armeabi-v7a x86_64)

if [[ -z "${ANDROID_NDK_HOME:-}" ]]; then
  SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-${HOME}/Android/Sdk}}"
  ANDROID_NDK_HOME="$(find "${SDK_DIR}/ndk" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort -V | tail -n 1)"
fi
if [[ -z "${ANDROID_NDK_HOME}" || ! -f "${ANDROID_NDK_HOME}/source.properties" ]]; then
  echo "no Android NDK found: set ANDROID_NDK_HOME or ANDROID_HOME" >&2
  exit 1
fi
export ANDROID_NDK_HOME

target_flags=()
for abi in "${ABIS[@]}"; do
  target_flags+=(--target "${abi}")
done

# cargo-ndk also copies the cdylibs some RGB dependencies declare; nothing
# links against them. Stage the build and install only this library, so an
# out-dir shared with other native libraries (the signer's) is left alone.
mkdir -p target
STAGING="$(mktemp -d target/android-stage.XXXXXX)"
trap 'rm -rf "${STAGING}"' EXIT
cargo ndk "${target_flags[@]}" --platform 24 --output-dir "${STAGING}" build --release --locked

for abi in "${ABIS[@]}"; do
  library="${STAGING}/${abi}/libutexo_rgb_verifier.so"
  if [[ ! -s "${library}" ]]; then
    echo "missing native library for ${abi}" >&2
    exit 1
  fi
  mkdir -p "${OUT_DIR}/${abi}"
  cp "${library}" "${OUT_DIR}/${abi}/libutexo_rgb_verifier.so"
done
