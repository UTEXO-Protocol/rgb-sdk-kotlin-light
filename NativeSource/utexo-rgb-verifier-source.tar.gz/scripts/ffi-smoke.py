"""Calls the built library through its generated UniFFI Python bindings.

Usage: ffi-smoke.py <bindings-dir> <fixture.json>

The Python bindings drive the same exported C ABI and scaffolding as the
Kotlin and Swift ones, so this checks the boundary itself: records, enums,
bytes, u64 entropy and typed errors all round-trip.
"""

import json
import sys

sys.path.insert(0, sys.argv[1])
import utexo_rgb_verifier as verifier  # noqa: E402

with open(sys.argv[2], encoding="utf-8") as handle:
    fixture = json.load(handle)


def request(**overrides):
    fields = {
        "network": verifier.Network.REGTEST,
        "accounts": verifier.WalletAccounts(
            master_fingerprint=fixture["masterFingerprint"],
            account_xpub_vanilla=fixture["accountXpubVanilla"],
            account_xpub_colored=fixture["accountXpubColored"],
        ),
        "psbt_base64": fixture["psbtBase64"],
        "fascia": bytes.fromhex(fixture["fasciaHex"]),
        "mpc_entropy": int(fixture["mpcEntropy"]),
        "invoice": fixture["invoice"],
        "asset_id": fixture["assetId"],
        "amount": fixture["amount"],
        "existing_output_proofs": [],
        "max_derivation_index": fixture["maxDerivationIndex"],
    }
    fields.update(overrides)
    return verifier.RgbSendRequest(**fields)


def expect_error(variant, **overrides):
    try:
        verifier.verify_rgb_send(request(**overrides))
    except variant as error:
        return str(error)
    raise AssertionError(f"expected {variant.__name__}")


expected = fixture["expected"]
verdict = verifier.verify_rgb_send(request())
assert verdict.profile == verifier.verifier_profile()
assert verdict.txid == expected["txid"]
assert verdict.asset_id == fixture["assetId"]
assert verdict.recipient.seal.is_blinded()
assert verdict.recipient.amount == expected["recipientAmount"]
[retained] = verdict.retained
assert retained.state.is_amount() and retained.state.value == expected["retainedAmount"]
assert retained.seal.is_witness_output() and retained.seal.vout == expected["retainedVout"]

message = expect_error(
    verifier.VerifierError.Rejected, mpc_entropy=int(fixture["mpcEntropy"]) ^ 1
)
assert "does not commit" in message, message

bad_xpub = fixture["accountXpubColored"][:-4] + "zzzz"
accounts = verifier.WalletAccounts(
    master_fingerprint=fixture["masterFingerprint"],
    account_xpub_vanilla=fixture["accountXpubVanilla"],
    account_xpub_colored=bad_xpub,
)
message = expect_error(verifier.VerifierError.InvalidArgument, accounts=accounts)
assert bad_xpub not in message, "error message echoes caller input"

print(f"ffi smoke ok: {verdict.txid}")
