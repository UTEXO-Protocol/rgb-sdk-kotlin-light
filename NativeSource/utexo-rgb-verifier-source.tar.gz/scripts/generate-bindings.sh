#!/usr/bin/env bash
# Generates the Kotlin and Swift bindings.
#
# Usage: scripts/generate-bindings.sh [out-dir]   (default: target/bindings)
# Writes <out-dir>/kotlin/com/utexo/rgb/sdk/internal/ffi/verifier/*.kt and
# <out-dir>/swift/UtexoRgbVerifier{Bindings.swift,FFI.h,FFI.modulemap}.
set -euo pipefail

CORE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${CORE_DIR}"
OUT_DIR="${1:-target/bindings}"

case "$(uname -s)" in
  Darwin) LIBRARY="target/debug/libutexo_rgb_verifier.dylib" ;;
  *) LIBRARY="target/debug/libutexo_rgb_verifier.so" ;;
esac

cargo build --locked --features bindgen --bin uniffi-bindgen
cargo build --locked --lib

for language in kotlin swift; do
  target/debug/uniffi-bindgen generate \
    --config uniffi-bindgen.toml \
    "${LIBRARY}" \
    --language "${language}" \
    --no-format \
    --out-dir "${OUT_DIR}/${language}"
done
