# Verifier fixtures

All keys here come from the public BIP39 test mnemonic (eleven `abandon` words
followed by `about`, master fingerprint `73c5da0a`). Never fund them on a real
network.

`gateway-rgb-pr174.psbt` is a byte-for-byte copy of the `utexo-local-signer`
fixture of the same name (SHA-256
`2951d4dc3e3d2e5d08ff81478b53530066bc6d80e5b47d344cb3d6dc11876451`): an RGB send
that rgb-lib prepared behind the regtest gateway, unsigned txid
`e41e4ebdc769b0575126a5d728394d4c01206110e7eaebf6446029d5acd0d814`. Its fascia
and MPC entropy were not retained, so it only exercises PSBT decoding, opret
extraction and output ownership, not a full verification.

`ffi-smoke.json` is synthetic: a valid blinded send built through
`psrgbt::rgb_commit` by `ffi_smoke_fixture` in `src/tests.rs`. The
`ffi_smoke_fixture_is_current` test fails if the committed file drifts from
what the code builds; regenerate it with
`cargo test --locked write_ffi_smoke_fixture -- --ignored`.
`scripts/ffi-smoke.sh` feeds it through the generated bindings, and the Kotlin
and Swift SDK smoke tests can reuse it. `mpcEntropy` is a decimal string
because the value exceeds 2^53.
