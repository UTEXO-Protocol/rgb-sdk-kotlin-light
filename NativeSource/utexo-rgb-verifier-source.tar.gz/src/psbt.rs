use std::io::Cursor;

use base64::Engine;
use base64::engine::general_purpose::STANDARD;
use bitcoin::opcodes::all::OP_PUSHBYTES_32;
use bitcoin::psbt::Psbt;
use bitcoin::{Amount, Transaction};

use crate::error::{Result, invalid_argument, invalid_psbt, rejected};

pub(crate) const MAX_PSBT_BYTES: usize = 4 * 1024 * 1024;

pub(crate) fn decode_psbt(value: &str) -> Result<Psbt> {
    if value.trim() != value {
        return Err(invalid_psbt("PSBT must not contain surrounding whitespace"));
    }
    if value.is_empty() {
        return Err(invalid_argument("psbt must not be empty"));
    }
    if value.len()
        > MAX_PSBT_BYTES
            .saturating_mul(4)
            .saturating_div(3)
            .saturating_add(8)
    {
        return Err(invalid_psbt("PSBT exceeds the encoded size limit"));
    }
    let bytes = STANDARD
        .decode(value)
        .map_err(|_| invalid_psbt("base64 decoding failed"))?;
    if STANDARD.encode(&bytes) != value {
        return Err(invalid_psbt("PSBT must use canonical padded base64"));
    }
    if bytes.len() > MAX_PSBT_BYTES {
        return Err(invalid_psbt("PSBT exceeds the decoded size limit"));
    }
    let mut cursor = Cursor::new(bytes.as_slice());
    let psbt = Psbt::deserialize_from_reader(&mut cursor)
        .map_err(|_| invalid_psbt("binary PSBT parsing failed"))?;
    if usize::try_from(cursor.position()).ok() != Some(bytes.len()) {
        return Err(invalid_psbt("trailing bytes are not permitted"));
    }
    if psbt.outputs.len() != psbt.unsigned_tx.output.len() {
        return Err(invalid_psbt(
            "output maps do not match the transaction outputs",
        ));
    }
    Ok(psbt)
}

/// The opret commitment of the transaction about to be signed: the 32 bytes of
/// its single `OP_RETURN` output, read from the script itself rather than from
/// PSBT proprietary fields the preparer controls.
pub(crate) fn opret_commitment(transaction: &Transaction) -> Result<(usize, [u8; 32])> {
    let mut found = None;
    for (vout, txout) in transaction.output.iter().enumerate() {
        if !txout.script_pubkey.is_op_return() {
            continue;
        }
        if found.is_some() {
            return Err(rejected("transaction has more than one OP_RETURN output"));
        }
        let bytes = txout.script_pubkey.as_bytes();
        let commitment: [u8; 32] = match bytes {
            [_, push, rest @ ..] if *push == OP_PUSHBYTES_32.to_u8() => {
                rest.try_into().map_err(|_| {
                    rejected(format!(
                        "OP_RETURN output {vout} is not a 32-byte commitment"
                    ))
                })?
            }
            _ => {
                return Err(rejected(format!(
                    "OP_RETURN output {vout} is not a 32-byte commitment"
                )));
            }
        };
        if txout.value != Amount::ZERO {
            return Err(rejected(format!("OP_RETURN output {vout} carries bitcoin")));
        }
        found = Some((vout, commitment));
    }
    found.ok_or_else(|| rejected("transaction has no OP_RETURN commitment"))
}
