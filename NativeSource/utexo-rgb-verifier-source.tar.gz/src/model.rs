use bitcoin::NetworkKind;
use rgbcore::ChainNet;

/// Identifies the verification rules a verdict was produced under.
pub const VERIFIER_PROFILE: &str = "utexo.rgb-send.v1";

pub const VANILLA_COIN_MAINNET: u32 = 0;
pub const VANILLA_COIN_TESTNET: u32 = 1;
pub const COLORED_COIN_MAINNET: u32 = 827_166;
pub const COLORED_COIN_TESTNET: u32 = 827_167;
pub const PURPOSE_BIP86: u32 = 86;
pub const ACCOUNT_ZERO: u32 = 0;
/// rgb-lib derives every wallet script, vanilla and colored, on branch 0.
pub const KEYCHAIN_BRANCH: u32 = 0;

/// Same variants and meaning as the local signer's `Network`.
#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum Network {
    Mainnet,
    Testnet,
    Testnet4,
    Signet,
    Regtest,
    Utexo,
}

impl Network {
    pub(crate) const fn network_kind(self) -> NetworkKind {
        match self {
            Self::Mainnet => NetworkKind::Main,
            Self::Testnet | Self::Testnet4 | Self::Signet | Self::Regtest | Self::Utexo => {
                NetworkKind::Test
            }
        }
    }

    /// The RGB chain-network an invoice for this wallet must name.
    pub(crate) const fn chain_net(self) -> ChainNet {
        match self {
            Self::Mainnet => ChainNet::BitcoinMainnet,
            Self::Testnet => ChainNet::BitcoinTestnet3,
            Self::Testnet4 => ChainNet::BitcoinTestnet4,
            Self::Signet | Self::Utexo => ChainNet::BitcoinSignet,
            Self::Regtest => ChainNet::BitcoinRegtest,
        }
    }

    pub(crate) const fn coin_type(self, account: AccountKind) -> u32 {
        match (self, account) {
            (Self::Mainnet, AccountKind::Vanilla) => VANILLA_COIN_MAINNET,
            (Self::Mainnet, AccountKind::Colored) => COLORED_COIN_MAINNET,
            (_, AccountKind::Vanilla) => VANILLA_COIN_TESTNET,
            (_, AccountKind::Colored) => COLORED_COIN_TESTNET,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum AccountKind {
    Vanilla,
    Colored,
}

/// The wallet's public account keys, as the local signer's `WalletIdentity`
/// reports them. They must come from the device's own key derivation, never
/// from the gateway: every ownership proof re-derives from these.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct WalletAccounts {
    /// Master key fingerprint, 8 lowercase or uppercase hex characters.
    pub master_fingerprint: String,
    /// Account xpub at `m/86'/{0|1}'/0'`.
    pub account_xpub_vanilla: String,
    /// Account xpub at `m/86'/{827166|827167}'/0'`.
    pub account_xpub_colored: String,
}

/// Evidence that an existing UTXO, used as a seal outside the transaction
/// being signed, belongs to the wallet's colored account.
///
/// The transaction is self-authenticating: it must hash to the seal's txid, so
/// it can be fetched from any source, including the gateway.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct ExistingOutputProof {
    /// Consensus-serialized transaction that created the output.
    pub transaction: Vec<u8>,
    pub vout: u32,
    /// Index on the colored account's branch 0 (`m/86'/coin'/0'/0/index`).
    pub derivation_index: u32,
}

/// Everything needed to verify an unsigned RGB send before signing it.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct RgbSendRequest {
    pub network: Network,
    pub accounts: WalletAccounts,
    /// Unsigned PSBT exactly as prepared by the gateway, canonical base64.
    pub psbt_base64: String,
    /// Strict-encoded fascia from rgb-lib's `send_begin` (`details.fascia_path`).
    pub fascia: Vec<u8>,
    /// MPC tree entropy from rgb-lib's `send_begin` (`details.entropy`).
    pub mpc_entropy: u64,
    /// The RGB invoice the user is paying, exactly as the user supplied it.
    pub invoice: String,
    /// Asset the user approved sending (`rgb:…` contract id).
    pub asset_id: String,
    /// Amount of `asset_id` the user approved sending.
    pub amount: u64,
    /// One proof per existing-UTXO seal in the fascia; empty when there are none.
    pub existing_output_proofs: Vec<ExistingOutputProof>,
    /// Highest derivation index accepted for a wallet-owned output.
    pub max_derivation_index: u32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum RecipientSeal {
    /// Blinded `utxob:` beneficiary: an existing recipient UTXO.
    Blinded,
    /// Witness `wvout:` beneficiary: output `vout` of this transaction, whose
    /// script is the one the invoice encodes.
    WitnessOutput { vout: u32 },
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct RecipientAllocation {
    pub seal: RecipientSeal,
    pub assignment_type: u16,
    pub amount: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum AllocationState {
    Amount { value: u64 },
    Data,
    Rights,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum RetainedSeal {
    /// Output `vout` of this transaction, on the colored account.
    WitnessOutput { vout: u32, derivation_index: u32 },
    /// An existing UTXO outside this transaction, on the colored account.
    ExistingOutput {
        txid: String,
        vout: u32,
        derivation_index: u32,
    },
}

/// State the transaction assigns back to the wallet.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct RetainedAllocation {
    pub asset_id: String,
    pub assignment_type: u16,
    pub state: AllocationState,
    pub seal: RetainedSeal,
}

/// What the signature on this transaction authorizes, as far as RGB state is
/// concerned. Returned only when every check passed.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct RgbSendVerdict {
    pub profile: String,
    pub txid: String,
    pub asset_id: String,
    pub recipient: RecipientAllocation,
    /// Every other assignment of every committed transition.
    pub retained: Vec<RetainedAllocation>,
    /// Every contract the transaction's opret commits to, sorted.
    pub committed_asset_ids: Vec<String>,
    /// Every committed transition, sorted.
    pub transition_ids: Vec<String>,
}
