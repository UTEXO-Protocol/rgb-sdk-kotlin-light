use std::str::FromStr;

use bitcoin::ScriptBuf;
use rgbcore::{ContractId, SecretSeal};
use rgbinvoice::{Beneficiary as InvoiceBeneficiary, InvoiceState, RgbInvoice};

use crate::error::{Result, invalid_rgb_invoice};
use crate::model::Network;

const MAX_INVOICE_BYTES: usize = 4096;

/// Where the invoice asks the asset to be sent.
pub(crate) enum Beneficiary {
    /// A blinded seal on a recipient UTXO outside this transaction.
    Blinded(SecretSeal),
    /// A new output of this transaction paying exactly this script.
    Witness(ScriptBuf),
}

/// Decodes `value` and checks it requests what the user approved.
pub(crate) fn decode_beneficiary(
    value: &str,
    network: Network,
    asset: ContractId,
    amount: u64,
) -> Result<Beneficiary> {
    if value.is_empty() || value.len() > MAX_INVOICE_BYTES || value.trim() != value {
        return Err(invalid_rgb_invoice("invoice is empty, oversized or padded"));
    }
    let invoice =
        RgbInvoice::from_str(value).map_err(|_| invalid_rgb_invoice("invoice does not parse"))?;
    if invoice.beneficiary.chain_network() != network.chain_net() {
        return Err(invalid_rgb_invoice("invoice is for another network"));
    }
    if invoice.contract.is_some_and(|contract| contract != asset) {
        return Err(invalid_rgb_invoice(
            "invoice requests a different asset than the one approved",
        ));
    }
    match invoice.assignment_state {
        None => {}
        Some(InvoiceState::Amount(requested)) if requested.value() == amount => {}
        Some(InvoiceState::Amount(_)) => {
            return Err(invalid_rgb_invoice(
                "invoice requests a different amount than the one approved",
            ));
        }
        Some(_) => {
            return Err(invalid_rgb_invoice(
                "invoice does not request a fungible amount",
            ));
        }
    }
    Ok(match invoice.beneficiary.into_inner() {
        InvoiceBeneficiary::BlindedSeal(seal) => Beneficiary::Blinded(seal),
        InvoiceBeneficiary::WitnessVout(pay_to_vout, _) => {
            Beneficiary::Witness((*pay_to_vout).to_script())
        }
    })
}
