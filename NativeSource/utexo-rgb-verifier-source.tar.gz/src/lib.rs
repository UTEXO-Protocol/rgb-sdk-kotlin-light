//! Pre-sign RGB verification for UTEXO's mobile SDKs.
//!
//! The gateway prepares RGB sends server-side; the device signs them. Spending
//! a colored input authorizes whatever RGB transition the transaction commits
//! to, and that commitment is opaque to bitcoin-level policy. This crate opens
//! it: given the unsigned PSBT, rgb-lib's fascia and MPC entropy, the user's
//! invoice and approved amount, and the wallet's account xpubs, it proves that
//! every allocation the signature would move goes either to the invoice's
//! beneficiary, in exactly the approved amount, or back to the wallet.
//!
//! It does not prove that the transitions are valid RGB history, or that no
//! allocation on a spent input was left out of the fascia. Either failure
//! destroys state rather than moving it to anyone; see the README.

mod error;
mod invoice;
mod keys;
mod model;
mod psbt;
mod rgb;
mod verify;

#[cfg(test)]
mod tests;

pub use error::VerifierError;
pub use model::{
    AccountKind, AllocationState, ExistingOutputProof, Network, RecipientAllocation, RecipientSeal,
    RetainedAllocation, RetainedSeal, RgbSendRequest, RgbSendVerdict, VERIFIER_PROFILE,
    WalletAccounts,
};

uniffi::setup_scaffolding!();

/// Verifies an unsigned RGB send before signing. Sign only on `Ok`.
///
/// # Errors
/// Returns `Rejected` when the transaction would move RGB state anywhere other
/// than the invoice's beneficiary and the wallet, and an input error for
/// malformed or inconsistent arguments. No network request is made.
#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns the boundary value.
pub fn verify_rgb_send(request: RgbSendRequest) -> Result<RgbSendVerdict, VerifierError> {
    verify::verify_rgb_send(&request)
}

/// The rule set `verify_rgb_send` applies, for compatibility checks.
#[uniffi::export]
#[must_use]
pub fn verifier_profile() -> String {
    VERIFIER_PROFILE.to_owned()
}
