use std::collections::{BTreeMap, BTreeSet};
use std::str::FromStr;

use amplify::Wrapper;
use bitcoin::OutPoint;
use bitcoin::psbt::Psbt;
use rgbcore::seals::txout::TxPtr;
use rgbcore::validation::DbcProof;
use rgbcore::{BuilderSeal, ContractId, GraphSeal, Transition, TypedAssigns};

use crate::error::{Result, invalid_argument, rejected};
use crate::invoice::{self, Beneficiary};
use crate::keys::{Accounts, OwnedOutput};
use crate::model::{
    AccountKind, AllocationState, ExistingOutputProof, RecipientAllocation, RecipientSeal,
    RetainedAllocation, RetainedSeal, RgbSendRequest, RgbSendVerdict, VERIFIER_PROFILE,
};
use crate::{psbt, rgb};

const MAX_EXISTING_OUTPUT_PROOFS: usize = 256;

/// What each output of the transaction is, proven before any RGB state is
/// looked at.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Role {
    Commitment,
    Owned(OwnedOutput),
    /// The output paying the witness invoice's script.
    Recipient,
}

pub(crate) fn verify_rgb_send(request: &RgbSendRequest) -> Result<RgbSendVerdict> {
    let accounts = Accounts::parse(
        request.network,
        &request.accounts,
        request.max_derivation_index,
    )?;
    let asset = ContractId::from_str(&request.asset_id)
        .map_err(|_| invalid_argument("asset id is not an RGB contract id"))?;
    if request.amount == 0 {
        return Err(invalid_argument("amount must be positive"));
    }
    let beneficiary =
        invoice::decode_beneficiary(&request.invoice, request.network, asset, request.amount)?;
    let psbt = psbt::decode_psbt(&request.psbt_base64)?;
    let transaction = &psbt.unsigned_tx;
    let txid = transaction.compute_txid();
    let fascia = rgb::decode_fascia(&request.fascia)?;
    let existing = prove_existing_outputs(&accounts, &request.existing_output_proofs)?;

    // The fascia must describe the transaction being signed, committed by opret.
    if fascia.witness_id() != txid {
        return Err(rejected("fascia was produced for a different transaction"));
    }
    if !matches!(fascia.seal_witness().dbc_proof, DbcProof::Opret(_)) {
        return Err(rejected("fascia does not use an opret commitment"));
    }
    let (opret_vout, opret) = psbt::opret_commitment(transaction)?;
    if rgb::recompute_commitment(&fascia, request.mpc_entropy)? != opret {
        return Err(rejected(
            "the transaction's opret does not commit to exactly the fascia's bundles",
        ));
    }

    let roles = output_roles(&accounts, &psbt, opret_vout, &beneficiary)?;
    let recipient_vout = roles
        .iter()
        .position(|role| *role == Role::Recipient)
        .and_then(|vout| u32::try_from(vout).ok());
    let spent: BTreeSet<OutPoint> = transaction
        .input
        .iter()
        .map(|input| input.previous_output)
        .collect();
    let disclosed = rgb::disclosed_transitions(&fascia)?;

    let mut recipients = Vec::new();
    let mut retained = Vec::new();
    for item in &disclosed {
        for_each_assignment(item.transition, |assignment_type, seal, state| {
            if is_recipient(seal, &beneficiary, recipient_vout) {
                recipients.push((item.contract, assignment_type, state));
                return Ok(());
            }
            retained.push(RetainedAllocation {
                asset_id: item.contract.to_string(),
                assignment_type,
                state,
                seal: retained_seal(seal, &roles, &spent, &existing)?,
            });
            Ok(())
        })?;
    }

    let recipient = recipient_allocation(
        &recipients,
        asset,
        request.amount,
        &beneficiary,
        recipient_vout,
    )?;
    let mut committed_asset_ids: Vec<String> =
        fascia.bundles().keys().map(ToString::to_string).collect();
    committed_asset_ids.sort();
    let mut transition_ids: Vec<String> =
        disclosed.iter().map(|item| item.opid.to_string()).collect();
    transition_ids.sort();

    Ok(RgbSendVerdict {
        profile: VERIFIER_PROFILE.to_owned(),
        txid: txid.to_string(),
        asset_id: asset.to_string(),
        recipient,
        retained,
        committed_asset_ids,
        transition_ids,
    })
}

/// The beneficiary must receive exactly one assignment: the approved amount of
/// the approved asset.
fn recipient_allocation(
    recipients: &[(ContractId, u16, AllocationState)],
    asset: ContractId,
    amount: u64,
    beneficiary: &Beneficiary,
    recipient_vout: Option<u32>,
) -> Result<RecipientAllocation> {
    let [(contract, assignment_type, state)] = recipients else {
        return Err(rejected(format!(
            "expected exactly one assignment to the invoice's beneficiary, found {}",
            recipients.len()
        )));
    };
    if *contract != asset {
        return Err(rejected(
            "the invoice's beneficiary receives a different asset than the one approved",
        ));
    }
    let AllocationState::Amount { value } = state else {
        return Err(rejected(
            "the invoice's beneficiary receives non-fungible state",
        ));
    };
    if *value != amount {
        return Err(rejected(
            "the invoice's beneficiary receives a different amount than the one approved",
        ));
    }
    let seal = match (beneficiary, recipient_vout) {
        (Beneficiary::Blinded(_), _) => RecipientSeal::Blinded,
        (Beneficiary::Witness(_), Some(vout)) => RecipientSeal::WitnessOutput { vout },
        (Beneficiary::Witness(_), None) => {
            return Err(rejected("no output pays the invoice's witness script"));
        }
    };
    Ok(RecipientAllocation {
        seal,
        assignment_type: *assignment_type,
        amount: *value,
    })
}

/// Every output must be the commitment, the wallet's own, or the single output
/// paying a witness invoice. A foreign output could otherwise carry a second,
/// tapret commitment; the wallet's own BIP86 outputs and the invoice's fixed
/// script cannot.
fn output_roles(
    accounts: &Accounts,
    psbt: &Psbt,
    opret_vout: usize,
    beneficiary: &Beneficiary,
) -> Result<Vec<Role>> {
    let mut roles = Vec::with_capacity(psbt.unsigned_tx.output.len());
    for (vout, (txout, output)) in psbt
        .unsigned_tx
        .output
        .iter()
        .zip(&psbt.outputs)
        .enumerate()
    {
        if vout == opret_vout {
            roles.push(Role::Commitment);
            continue;
        }
        let owned = accounts.classify_output(vout, output, txout)?;
        let pays_invoice = matches!(
            beneficiary,
            Beneficiary::Witness(script) if *script == txout.script_pubkey
        );
        roles.push(match (pays_invoice, owned) {
            (true, _) => Role::Recipient,
            (false, Some(owned)) => Role::Owned(owned),
            (false, None) => {
                return Err(rejected(format!(
                    "output {vout} pays a script that is neither the wallet's nor the invoice's"
                )));
            }
        });
    }
    let recipients = roles
        .iter()
        .filter(|role| **role == Role::Recipient)
        .count();
    if matches!(beneficiary, Beneficiary::Witness(_)) && recipients != 1 {
        return Err(rejected(format!(
            "expected exactly one output paying the invoice's witness script, found {recipients}"
        )));
    }
    Ok(roles)
}

fn prove_existing_outputs(
    accounts: &Accounts,
    proofs: &[ExistingOutputProof],
) -> Result<BTreeMap<OutPoint, u32>> {
    if proofs.len() > MAX_EXISTING_OUTPUT_PROOFS {
        return Err(invalid_argument("too many existing-output proofs"));
    }
    let mut proven = BTreeMap::new();
    for proof in proofs {
        let (txid, index) = accounts.prove_existing_output(proof)?;
        if proven
            .insert(OutPoint::new(txid, proof.vout), index)
            .is_some()
        {
            return Err(invalid_argument("an existing output is proven twice"));
        }
    }
    Ok(proven)
}

fn is_recipient(
    seal: &BuilderSeal<GraphSeal>,
    beneficiary: &Beneficiary,
    recipient_vout: Option<u32>,
) -> bool {
    match beneficiary {
        Beneficiary::Blinded(secret) => seal.to_secret_seal() == *secret,
        Beneficiary::Witness(_) => matches!(
            seal,
            BuilderSeal::Revealed(revealed)
                if revealed.txid == TxPtr::WitnessTx
                    && Some(revealed.vout.into_u32()) == recipient_vout
        ),
    }
}

/// Proves a non-recipient assignment lands on a seal the wallet controls.
fn retained_seal(
    seal: &BuilderSeal<GraphSeal>,
    roles: &[Role],
    spent: &BTreeSet<OutPoint>,
    existing: &BTreeMap<OutPoint, u32>,
) -> Result<RetainedSeal> {
    let BuilderSeal::Revealed(revealed) = seal else {
        return Err(rejected("RGB state is assigned to an undisclosed seal"));
    };
    let vout = revealed.vout.into_u32();
    match revealed.txid {
        TxPtr::WitnessTx => {
            let role = usize::try_from(vout).ok().and_then(|vout| roles.get(vout));
            match role {
                Some(Role::Owned(OwnedOutput {
                    account: AccountKind::Colored,
                    index,
                })) => Ok(RetainedSeal::WitnessOutput {
                    vout,
                    derivation_index: *index,
                }),
                Some(Role::Owned(_)) => Err(rejected(format!(
                    "RGB state is assigned to output {vout}, which is on the vanilla account"
                ))),
                Some(Role::Commitment) => {
                    Err(rejected("RGB state is assigned to the OP_RETURN output"))
                }
                Some(Role::Recipient) => Err(rejected(format!(
                    "output {vout}, the invoice's witness output, receives more than the payment"
                ))),
                None => Err(rejected(format!(
                    "RGB state is assigned to output {vout}, which does not exist"
                ))),
            }
        }
        TxPtr::Txid(txid) => {
            let outpoint = OutPoint::new(txid, vout);
            if spent.contains(&outpoint) {
                return Err(rejected(
                    "RGB state is assigned to an output this transaction spends",
                ));
            }
            let index = existing.get(&outpoint).ok_or_else(|| {
                rejected("RGB state is assigned to an existing output with no ownership proof")
            })?;
            Ok(RetainedSeal::ExistingOutput {
                txid: txid.to_string(),
                vout,
                derivation_index: *index,
            })
        }
    }
}

fn for_each_assignment(
    transition: &Transition,
    mut visit: impl FnMut(u16, &BuilderSeal<GraphSeal>, AllocationState) -> Result<()>,
) -> Result<()> {
    for (assignment_type, typed) in transition.assignments.iter() {
        let assignment_type = assignment_type.to_inner();
        match typed {
            TypedAssigns::Declarative(items) => {
                for item in items.iter() {
                    visit(assignment_type, &item.seal, AllocationState::Rights)?;
                }
            }
            TypedAssigns::Fungible(items) => {
                for item in items.iter() {
                    let value = item.state.as_u64();
                    visit(
                        assignment_type,
                        &item.seal,
                        AllocationState::Amount { value },
                    )?;
                }
            }
            TypedAssigns::Structured(items) => {
                for item in items.iter() {
                    visit(assignment_type, &item.seal, AllocationState::Data)?;
                }
            }
        }
    }
    Ok(())
}
