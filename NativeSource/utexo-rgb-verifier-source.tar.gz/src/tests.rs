#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

//! Every fixture is built through `psrgbt::rgb_commit`, the code path rgb-lib's
//! `send_begin` uses, so commitments and fascias are real rather than mocked.
//! Each attack test then changes exactly one thing a hostile preparer controls.

use std::collections::BTreeMap;

use amplify::confinement::{Confined, NonEmptyOrdMap, NonEmptyOrdSet, NonEmptyVec, U32};
use amplify::{ByteArray, Wrapper};
use base64::Engine;
use base64::engine::general_purpose::STANDARD;
use bitcoin::absolute::LockTime;
use bitcoin::bip32::{ChildNumber, DerivationPath, Fingerprint, Xpriv, Xpub};
use bitcoin::hashes::Hash;
use bitcoin::key::TapTweak;
use bitcoin::psbt::{Output as PsbtOutput, Psbt};
use bitcoin::secp256k1::{All, Keypair, Secp256k1, SecretKey, XOnlyPublicKey};
use bitcoin::transaction::Version;
use bitcoin::{Amount, OutPoint, ScriptBuf, Sequence, Transaction, TxIn, TxOut, Txid};
use psrgbt::{RgbOutExt, RgbPsbtExt};
use rgbcore::assignments::AssignVec;
use rgbcore::commit_verify::Conceal;
use rgbcore::seals::txout::{BlindSeal, CloseMethod, TxPtr};
use rgbcore::{
    Assign, AssignmentType, Assignments, BuilderSeal, ContractId, Ffv, GlobalState, GraphSeal,
    Inputs, Metadata, OpId, Opout, RevealedValue, SecretSeal, Transition, TransitionBundle,
    TransitionType, TypedAssigns,
};
use rgbinvoice::{Beneficiary, Pay2Vout, RgbInvoiceBuilder, XChainNet};
use rgbstd::containers::Fascia;
use strict_encoding::StrictSerialize;

use crate::keys::Accounts;
use crate::model::{AccountKind, KEYCHAIN_BRANCH};
use crate::{
    AllocationState, ExistingOutputProof, Network, RecipientSeal, RetainedSeal, RgbSendRequest,
    RgbSendVerdict, VerifierError, WalletAccounts, verifier_profile, verify_rgb_send,
};

/// BIP39 seed of the public test mnemonic "abandon" x11 + "about".
const SEED_HEX: &str = "5eb00bbddcf069084889a8ab9155568165f5c453ccb85e70811aaed6f6da5fc1\
                        9a5ac40b389cd370d086206dec8aa6c43daea6690f20ad3d8d48b2d2ce9e38e4";
const GATEWAY_RGB_PSBT: &str = include_str!("../tests/fixtures/gateway-rgb-pr174.psbt");
const NETWORK: Network = Network::Regtest;
const ASSET_TYPE: u16 = 4000;
const ENTROPY: u64 = 0x0102_0304_0506_0708;

fn hardened(index: u32) -> ChildNumber {
    ChildNumber::from_hardened_idx(index).unwrap()
}

fn normal(index: u32) -> ChildNumber {
    ChildNumber::from_normal_idx(index).unwrap()
}

struct TestWallet {
    secp: Secp256k1<All>,
    master: Xpriv,
    fingerprint: Fingerprint,
}

impl TestWallet {
    fn new() -> Self {
        let secp = Secp256k1::new();
        let master =
            Xpriv::new_master(NETWORK.network_kind(), &hex::decode(SEED_HEX).unwrap()).unwrap();
        let fingerprint = master.fingerprint(&secp);
        Self {
            secp,
            master,
            fingerprint,
        }
    }

    fn account_xpub(&self, account: AccountKind) -> Xpub {
        let path = [
            hardened(86),
            hardened(NETWORK.coin_type(account)),
            hardened(0),
        ];
        Xpub::from_priv(
            &self.secp,
            &self.master.derive_priv(&self.secp, &path).unwrap(),
        )
    }

    fn accounts(&self) -> WalletAccounts {
        WalletAccounts {
            master_fingerprint: self.fingerprint.to_string(),
            account_xpub_vanilla: self.account_xpub(AccountKind::Vanilla).to_string(),
            account_xpub_colored: self.account_xpub(AccountKind::Colored).to_string(),
        }
    }

    fn path(account: AccountKind, index: u32) -> DerivationPath {
        DerivationPath::from(vec![
            hardened(86),
            hardened(NETWORK.coin_type(account)),
            hardened(0),
            normal(KEYCHAIN_BRANCH),
            normal(index),
        ])
    }

    fn key(&self, account: AccountKind, index: u32) -> XOnlyPublicKey {
        let xpriv = self
            .master
            .derive_priv(&self.secp, &Self::path(account, index))
            .unwrap();
        xpriv
            .private_key
            .public_key(&self.secp)
            .x_only_public_key()
            .0
    }

    fn script(&self, account: AccountKind, index: u32) -> ScriptBuf {
        ScriptBuf::new_p2tr(&self.secp, self.key(account, index), None)
    }

    /// An output carrying the BIP86 metadata rgb-lib attaches to its own outputs.
    fn owned(&self, account: AccountKind, index: u32, sats: u64) -> (TxOut, PsbtOutput) {
        let key = self.key(account, index);
        let mut output = PsbtOutput {
            tap_internal_key: Some(key),
            ..PsbtOutput::default()
        };
        output.tap_key_origins.insert(
            key,
            (vec![], (self.fingerprint, Self::path(account, index))),
        );
        (
            TxOut {
                value: Amount::from_sat(sats),
                script_pubkey: self.script(account, index),
            },
            output,
        )
    }
}

fn foreign_key(byte: u8) -> XOnlyPublicKey {
    let secp = Secp256k1::new();
    let secret = SecretKey::from_slice(&[byte; 32]).unwrap();
    Keypair::from_secret_key(&secp, &secret)
        .x_only_public_key()
        .0
}

fn foreign(byte: u8, sats: u64) -> (TxOut, PsbtOutput) {
    let secp = Secp256k1::new();
    (
        TxOut {
            value: Amount::from_sat(sats),
            script_pubkey: ScriptBuf::new_p2tr(&secp, foreign_key(byte), None),
        },
        PsbtOutput::default(),
    )
}

fn op_return() -> (TxOut, PsbtOutput) {
    (
        TxOut {
            value: Amount::ZERO,
            script_pubkey: ScriptBuf::new_op_return([]),
        },
        PsbtOutput::default(),
    )
}

fn asset(byte: u8) -> ContractId {
    ContractId::from_byte_array([byte; 32])
}

fn opout(byte: u8, no: u16) -> Opout {
    Opout::new(
        OpId::from_byte_array([byte; 32]),
        AssignmentType::with(ASSET_TYPE),
        no,
    )
}

fn blinded_seal(byte: u8) -> SecretSeal {
    BlindSeal::<Txid>::with_blinding(Txid::from_byte_array([byte; 32]), 1u32, 77).conceal()
}

fn to_vout(vout: u32) -> BuilderSeal<GraphSeal> {
    BuilderSeal::Revealed(GraphSeal::with_blinded_vout(vout, u64::from(vout) + 1000))
}

fn to_existing(txid: Txid, vout: u32) -> BuilderSeal<GraphSeal> {
    BuilderSeal::Revealed(GraphSeal::with_blinding(TxPtr::Txid(txid), vout, 4242))
}

fn transition(
    contract: ContractId,
    inputs: &[Opout],
    assignments: Vec<(BuilderSeal<GraphSeal>, u64)>,
) -> Transition {
    let assigns: Vec<_> = assignments
        .into_iter()
        .map(|(seal, value)| Assign::with(seal, RevealedValue::from(value)))
        .collect();
    let typed = TypedAssigns::Fungible(AssignVec::with(NonEmptyVec::try_from(assigns).unwrap()));
    let map = BTreeMap::from([(AssignmentType::with(ASSET_TYPE), typed)]);
    Transition {
        ffv: Ffv::default(),
        contract_id: contract,
        nonce: u64::MAX,
        transition_type: TransitionType::with(10_000),
        metadata: Metadata::default(),
        globals: GlobalState::default(),
        inputs: Inputs::from(NonEmptyOrdSet::try_from_iter(inputs.iter().copied()).unwrap()),
        assignments: Assignments::from_inner(Confined::try_from(map).unwrap()),
        signature: None,
    }
}

fn blinded_invoice(contract: Option<ContractId>, amount: Option<u64>, seal: SecretSeal) -> String {
    let mut builder = RgbInvoiceBuilder::new(XChainNet::with(
        NETWORK.chain_net(),
        Beneficiary::BlindedSeal(seal),
    ));
    if let Some(contract) = contract {
        builder = builder.set_contract(contract);
    }
    if let Some(amount) = amount {
        builder = builder.set_amount_raw(amount);
    }
    builder.finish().to_string()
}

fn witness_invoice(contract: ContractId, amount: u64, key: XOnlyPublicKey) -> String {
    let secp = Secp256k1::new();
    let (output_key, _) = key.tap_tweak(&secp, None);
    let mut payload = [0u8; 33];
    payload[0] = 5; // P2TR
    payload[1..].copy_from_slice(&output_key.to_x_only_public_key().serialize());
    let beneficiary = Beneficiary::WitnessVout(Pay2Vout::try_from(payload).unwrap(), None);
    RgbInvoiceBuilder::new(XChainNet::with(NETWORK.chain_net(), beneficiary))
        .set_contract(contract)
        .set_amount_raw(amount)
        .finish()
        .to_string()
}

/// One prepared send: what an honest or hostile preparer could hand the device.
struct Scenario {
    wallet: TestWallet,
    inputs: Vec<OutPoint>,
    outputs: Vec<(TxOut, PsbtOutput)>,
    transitions: Vec<Transition>,
    invoice: String,
    asset: ContractId,
    amount: u64,
    proofs: Vec<ExistingOutputProof>,
}

struct Built {
    psbt: Psbt,
    fascia: Fascia,
}

impl Scenario {
    /// Sends 10 of asset 0x11 to a blinded seal, keeping 90 as RGB change on
    /// colored output 1 and BTC change on vanilla output 2.
    fn blinded() -> Self {
        let wallet = TestWallet::new();
        let outputs = vec![
            op_return(),
            wallet.owned(AccountKind::Colored, 1, 1_000),
            wallet.owned(AccountKind::Vanilla, 2, 50_000),
        ];
        let transitions = vec![transition(
            asset(0x11),
            &[opout(0x22, 0)],
            vec![
                (BuilderSeal::Concealed(blinded_seal(0x33)), 10),
                (to_vout(1), 90),
            ],
        )];
        Self {
            wallet,
            inputs: vec![OutPoint::new(Txid::from_byte_array([0x55; 32]), 0)],
            outputs,
            transitions,
            invoice: blinded_invoice(Some(asset(0x11)), Some(10), blinded_seal(0x33)),
            asset: asset(0x11),
            amount: 10,
            proofs: vec![],
        }
    }

    /// Sends 10 of asset 0x11 to a new output 1 paying the invoice's script.
    fn witness() -> Self {
        let wallet = TestWallet::new();
        let outputs = vec![
            op_return(),
            foreign(0x66, 1_000),
            wallet.owned(AccountKind::Colored, 1, 1_000),
            wallet.owned(AccountKind::Vanilla, 2, 50_000),
        ];
        let transitions = vec![transition(
            asset(0x11),
            &[opout(0x22, 0)],
            vec![(to_vout(1), 10), (to_vout(2), 90)],
        )];
        Self {
            wallet,
            inputs: vec![OutPoint::new(Txid::from_byte_array([0x55; 32]), 0)],
            outputs,
            transitions,
            invoice: witness_invoice(asset(0x11), 10, foreign_key(0x66)),
            asset: asset(0x11),
            amount: 10,
            proofs: vec![],
        }
    }

    fn build(&self) -> Built {
        let transaction = Transaction {
            version: Version::TWO,
            lock_time: LockTime::ZERO,
            input: self
                .inputs
                .iter()
                .map(|previous_output| TxIn {
                    previous_output: *previous_output,
                    sequence: Sequence::ENABLE_RBF_NO_LOCKTIME,
                    ..TxIn::default()
                })
                .collect(),
            output: self
                .outputs
                .iter()
                .map(|(txout, _)| txout.clone())
                .collect(),
        };
        let mut psbt = Psbt::from_unsigned_tx(transaction).unwrap();
        for (index, (_, output)) in self.outputs.iter().enumerate() {
            psbt.outputs[index] = output.clone();
        }
        // The same sequence as rgb-lib's `color_psbt`.
        for transition in &self.transitions {
            psbt.push_rgb_transition(transition.clone()).unwrap();
        }
        psbt.set_opret_host();
        let host = psbt
            .unsigned_tx
            .output
            .iter()
            .position(|txout| txout.script_pubkey.is_op_return())
            .unwrap();
        psbt.outputs[host].set_mpc_entropy(ENTROPY).unwrap();
        psbt.set_rgb_close_method(CloseMethod::OpretFirst);
        psbt.set_as_unmodifiable();
        let fascia = psbt.rgb_commit().unwrap();
        Built { psbt, fascia }
    }

    fn request(&self, psbt: &Psbt, fascia: &Fascia) -> RgbSendRequest {
        RgbSendRequest {
            network: NETWORK,
            accounts: self.wallet.accounts(),
            psbt_base64: STANDARD.encode(psbt.serialize()),
            fascia: fascia.to_strict_serialized::<U32>().unwrap().release(),
            mpc_entropy: ENTROPY,
            invoice: self.invoice.clone(),
            asset_id: self.asset.to_string(),
            amount: self.amount,
            existing_output_proofs: self.proofs.clone(),
            max_derivation_index: 10_000,
        }
    }

    fn verify(&self) -> Result<RgbSendVerdict, VerifierError> {
        let built = self.build();
        verify_rgb_send(self.request(&built.psbt, &built.fascia))
    }
}

fn with_bundles(
    fascia: &Fascia,
    edit: impl FnOnce(&mut BTreeMap<ContractId, TransitionBundle>),
) -> Fascia {
    let mut bundles: BTreeMap<_, _> = fascia
        .bundles()
        .iter()
        .map(|(contract, bundle)| (*contract, bundle.clone()))
        .collect();
    edit(&mut bundles);
    Fascia::new(
        fascia.seal_witness().clone(),
        NonEmptyOrdMap::try_from(bundles).unwrap(),
    )
}

fn rejection(result: Result<RgbSendVerdict, VerifierError>) -> String {
    match result {
        Err(VerifierError::Rejected { reason }) => reason,
        other => panic!("expected a rejection, got {other:?}"),
    }
}

// --- Accepted sends -------------------------------------------------------

#[test]
fn accepts_a_blinded_send_and_reports_where_the_change_goes() {
    let scenario = Scenario::blinded();
    let built = scenario.build();
    let verdict = verify_rgb_send(scenario.request(&built.psbt, &built.fascia)).unwrap();

    assert_eq!(verdict.profile, verifier_profile());
    assert_eq!(
        verdict.txid,
        built.psbt.unsigned_tx.compute_txid().to_string()
    );
    assert_eq!(verdict.asset_id, asset(0x11).to_string());
    assert_eq!(verdict.recipient.seal, RecipientSeal::Blinded);
    assert_eq!(verdict.recipient.amount, 10);
    assert_eq!(verdict.recipient.assignment_type, ASSET_TYPE);
    assert_eq!(verdict.committed_asset_ids, vec![asset(0x11).to_string()]);
    assert_eq!(verdict.transition_ids.len(), 1);
    assert_eq!(verdict.retained.len(), 1);
    assert_eq!(
        verdict.retained[0].state,
        AllocationState::Amount { value: 90 }
    );
    assert_eq!(
        verdict.retained[0].seal,
        RetainedSeal::WitnessOutput {
            vout: 1,
            derivation_index: 1
        }
    );
}

#[test]
fn accepts_a_witness_send_to_the_invoice_script() {
    let verdict = Scenario::witness().verify().unwrap();
    assert_eq!(
        verdict.recipient.seal,
        RecipientSeal::WitnessOutput { vout: 1 }
    );
    assert_eq!(verdict.recipient.amount, 10);
    assert_eq!(
        verdict.retained[0].seal,
        RetainedSeal::WitnessOutput {
            vout: 2,
            derivation_index: 1
        }
    );
}

#[test]
fn accepts_an_asset_agnostic_invoice_for_the_approved_amount() {
    let mut scenario = Scenario::blinded();
    scenario.invoice = blinded_invoice(None, None, blinded_seal(0x33));
    assert!(scenario.verify().is_ok());
}

#[test]
fn accepts_other_assets_on_spent_inputs_carried_forward_to_the_wallet() {
    let mut scenario = Scenario::blinded();
    scenario.transitions.push(transition(
        asset(0x77),
        &[opout(0x88, 0)],
        vec![(to_vout(1), 500)],
    ));
    let verdict = scenario.verify().unwrap();
    assert_eq!(verdict.committed_asset_ids.len(), 2);
    assert!(verdict.retained.iter().any(|allocation| {
        allocation.asset_id == asset(0x77).to_string()
            && allocation.state == AllocationState::Amount { value: 500 }
    }));
}

#[test]
fn accepts_change_on_an_existing_colored_utxo_with_a_proof() {
    let mut scenario = Scenario::blinded();
    let funding = Transaction {
        version: Version::TWO,
        lock_time: LockTime::ZERO,
        input: vec![TxIn::default()],
        output: vec![scenario.wallet.owned(AccountKind::Colored, 7, 1_000).0],
    };
    let funding_txid = funding.compute_txid();
    scenario.transitions = vec![transition(
        asset(0x11),
        &[opout(0x22, 0)],
        vec![
            (BuilderSeal::Concealed(blinded_seal(0x33)), 10),
            (to_existing(funding_txid, 0), 90),
        ],
    )];
    scenario.proofs = vec![ExistingOutputProof {
        transaction: bitcoin::consensus::serialize(&funding),
        vout: 0,
        derivation_index: 7,
    }];
    let verdict = scenario.verify().unwrap();
    assert_eq!(
        verdict.retained[0].seal,
        RetainedSeal::ExistingOutput {
            txid: funding_txid.to_string(),
            vout: 0,
            derivation_index: 7
        }
    );

    scenario.proofs[0].derivation_index = 8;
    assert!(rejection(scenario.verify()).contains("colored account"));
    scenario.proofs.clear();
    assert!(rejection(scenario.verify()).contains("no ownership proof"));
}

// --- The commitment ------------------------------------------------------

#[test]
fn rejects_a_fascia_that_hides_a_committed_contract() {
    let mut scenario = Scenario::blinded();
    // The opret also commits to a transition of asset 0x77 that moves its
    // allocation to an attacker's seal...
    scenario.transitions.push(transition(
        asset(0x77),
        &[opout(0x88, 0)],
        vec![(BuilderSeal::Concealed(blinded_seal(0x99)), 500)],
    ));
    let built = scenario.build();
    // ...but the device is shown a fascia without it.
    let hidden = with_bundles(&built.fascia, |bundles| {
        bundles.remove(&asset(0x77));
    });
    let reason = rejection(verify_rgb_send(scenario.request(&built.psbt, &hidden)));
    assert!(reason.contains("does not commit to exactly"), "{reason}");
}

#[test]
fn rejects_the_wrong_mpc_entropy() {
    let scenario = Scenario::blinded();
    let built = scenario.build();
    let mut request = scenario.request(&built.psbt, &built.fascia);
    request.mpc_entropy ^= 1;
    assert!(rejection(verify_rgb_send(request)).contains("does not commit to exactly"));
}

#[test]
fn rejects_a_fascia_built_for_another_transaction() {
    let scenario = Scenario::blinded();
    let built = scenario.build();
    let mut psbt = built.psbt.clone();
    psbt.unsigned_tx.output[2].value = Amount::from_sat(49_000);
    let reason = rejection(verify_rgb_send(scenario.request(&psbt, &built.fascia)));
    assert!(reason.contains("different transaction"), "{reason}");
}

#[test]
fn rejects_a_second_op_return_output() {
    let mut scenario = Scenario::blinded();
    scenario.outputs.push(op_return());
    assert!(rejection(scenario.verify()).contains("more than one OP_RETURN"));
}

// --- Disclosure ----------------------------------------------------------

#[test]
fn rejects_a_committed_transition_that_is_not_disclosed() {
    let mut scenario = Scenario::blinded();
    // A second transition of the same asset sends another allocation away.
    scenario.transitions.push(transition(
        asset(0x11),
        &[opout(0x23, 0)],
        vec![(BuilderSeal::Concealed(blinded_seal(0x99)), 1_000)],
    ));
    let built = scenario.build();
    // The bundle id commits only to the input map, so dropping the transition
    // from the disclosed list leaves the opret commitment intact.
    let hidden = with_bundles(&built.fascia, |bundles| {
        let bundle = bundles.get_mut(&asset(0x11)).unwrap();
        let shown: Vec<_> = bundle
            .known_transitions
            .iter()
            .filter(|known| known.transition.inputs().contains(&opout(0x22, 0)))
            .cloned()
            .collect();
        bundle.known_transitions = NonEmptyVec::try_from(shown).unwrap();
    });
    let reason = rejection(verify_rgb_send(scenario.request(&built.psbt, &hidden)));
    assert!(reason.contains("does not disclose"), "{reason}");
}

#[test]
fn rejects_a_disclosed_transition_that_does_not_hash_to_its_id() {
    let scenario = Scenario::blinded();
    let built = scenario.build();
    let forged = with_bundles(&built.fascia, |bundles| {
        let bundle = bundles.get_mut(&asset(0x11)).unwrap();
        let mut known: Vec<_> = bundle.known_transitions.iter().cloned().collect();
        // Same claimed opid, different content: the change goes to an attacker.
        known[0].transition.assignments = transition(
            asset(0x11),
            &[opout(0x22, 0)],
            vec![
                (BuilderSeal::Concealed(blinded_seal(0x33)), 10),
                (BuilderSeal::Concealed(blinded_seal(0x99)), 90),
            ],
        )
        .assignments;
        bundle.known_transitions = NonEmptyVec::try_from(known).unwrap();
    });
    let reason = rejection(verify_rgb_send(scenario.request(&built.psbt, &forged)));
    assert!(reason.contains("does not hash"), "{reason}");
}

// --- Where state goes ----------------------------------------------------

#[test]
fn rejects_change_sent_to_an_undisclosed_seal() {
    let mut scenario = Scenario::blinded();
    scenario.transitions = vec![transition(
        asset(0x11),
        &[opout(0x22, 0)],
        vec![
            (BuilderSeal::Concealed(blinded_seal(0x33)), 10),
            (BuilderSeal::Concealed(blinded_seal(0x99)), 90),
        ],
    )];
    assert!(rejection(scenario.verify()).contains("undisclosed seal"));
}

#[test]
fn rejects_another_asset_carried_forward_to_an_attacker() {
    let mut scenario = Scenario::blinded();
    scenario.transitions.push(transition(
        asset(0x77),
        &[opout(0x88, 0)],
        vec![(BuilderSeal::Concealed(blinded_seal(0x99)), 500)],
    ));
    assert!(rejection(scenario.verify()).contains("undisclosed seal"));
}

#[test]
fn rejects_rgb_state_on_the_vanilla_account() {
    let mut scenario = Scenario::blinded();
    scenario.transitions = vec![transition(
        asset(0x11),
        &[opout(0x22, 0)],
        vec![
            (BuilderSeal::Concealed(blinded_seal(0x33)), 10),
            (to_vout(2), 90),
        ],
    )];
    assert!(rejection(scenario.verify()).contains("vanilla account"));
}

#[test]
fn rejects_a_foreign_output_in_a_blinded_send() {
    let mut scenario = Scenario::blinded();
    scenario.outputs.push(foreign(0x66, 2_000));
    assert!(rejection(scenario.verify()).contains("neither the wallet's nor the invoice's"));
}

#[test]
fn rejects_extra_state_on_the_witness_recipient_output() {
    let mut scenario = Scenario::witness();
    scenario.transitions.push(transition(
        asset(0x77),
        &[opout(0x88, 0)],
        vec![(to_vout(1), 500)],
    ));
    assert!(rejection(scenario.verify()).contains("exactly one assignment"));
}

#[test]
fn rejects_change_on_an_output_the_transaction_spends() {
    let mut scenario = Scenario::blinded();
    let spent = scenario.inputs[0];
    scenario.transitions = vec![transition(
        asset(0x11),
        &[opout(0x22, 0)],
        vec![
            (BuilderSeal::Concealed(blinded_seal(0x33)), 10),
            (to_existing(spent.txid, spent.vout), 90),
        ],
    )];
    assert!(rejection(scenario.verify()).contains("this transaction spends"));
}

#[test]
fn rejects_an_output_that_falsely_claims_to_be_the_wallets() {
    let mut scenario = Scenario::blinded();
    // Colored-account metadata on an attacker's script.
    scenario.outputs[1].0.script_pubkey = foreign(0x66, 0).0.script_pubkey;
    assert!(rejection(scenario.verify()).contains("does not re-derive"));
}

// --- The recipient -------------------------------------------------------

#[test]
fn rejects_a_recipient_amount_other_than_the_approved_one() {
    let mut scenario = Scenario::blinded();
    scenario.invoice = blinded_invoice(Some(asset(0x11)), None, blinded_seal(0x33));
    scenario.transitions = vec![transition(
        asset(0x11),
        &[opout(0x22, 0)],
        vec![
            (BuilderSeal::Concealed(blinded_seal(0x33)), 9),
            (to_vout(1), 91),
        ],
    )];
    assert!(rejection(scenario.verify()).contains("different amount"));
}

#[test]
fn rejects_a_send_that_does_not_pay_the_invoice() {
    let mut scenario = Scenario::blinded();
    scenario.invoice = blinded_invoice(Some(asset(0x11)), Some(10), blinded_seal(0x34));
    // What actually receives the 10 is now just an undisclosed seal.
    assert!(rejection(scenario.verify()).contains("undisclosed seal"));
}

#[test]
fn rejects_two_assignments_to_the_beneficiary() {
    let mut scenario = Scenario::blinded();
    scenario.transitions = vec![transition(
        asset(0x11),
        &[opout(0x22, 0)],
        vec![
            (BuilderSeal::Concealed(blinded_seal(0x33)), 10),
            (BuilderSeal::Concealed(blinded_seal(0x33)), 10),
            (to_vout(1), 80),
        ],
    )];
    assert!(rejection(scenario.verify()).contains("exactly one assignment"));
}

#[test]
fn rejects_the_beneficiary_receiving_another_asset() {
    let mut scenario = Scenario::blinded();
    scenario.invoice = blinded_invoice(None, Some(10), blinded_seal(0x33));
    scenario.transitions = vec![
        transition(asset(0x11), &[opout(0x22, 0)], vec![(to_vout(1), 100)]),
        transition(
            asset(0x77),
            &[opout(0x88, 0)],
            vec![(BuilderSeal::Concealed(blinded_seal(0x33)), 10)],
        ),
    ];
    assert!(rejection(scenario.verify()).contains("different asset"));
}

#[test]
fn rejects_a_witness_send_without_an_output_paying_the_invoice() {
    let mut scenario = Scenario::witness();
    scenario.invoice = witness_invoice(asset(0x11), 10, foreign_key(0x67));
    // Output 1 now pays a script that neither the wallet nor the invoice names.
    assert!(rejection(scenario.verify()).contains("neither the wallet's nor the invoice's"));
}

// --- Inputs the caller supplies ------------------------------------------

#[test]
fn rejects_an_invoice_that_contradicts_the_approval() {
    let mut scenario = Scenario::blinded();
    scenario.invoice = blinded_invoice(Some(asset(0x12)), Some(10), blinded_seal(0x33));
    assert!(matches!(
        scenario.verify(),
        Err(VerifierError::InvalidRgbInvoice { .. })
    ));
    scenario.invoice = blinded_invoice(Some(asset(0x11)), Some(11), blinded_seal(0x33));
    assert!(matches!(
        scenario.verify(),
        Err(VerifierError::InvalidRgbInvoice { .. })
    ));
    scenario.invoice = RgbInvoiceBuilder::new(XChainNet::with(
        Network::Mainnet.chain_net(),
        Beneficiary::BlindedSeal(blinded_seal(0x33)),
    ))
    .finish()
    .to_string();
    assert!(matches!(
        scenario.verify(),
        Err(VerifierError::InvalidRgbInvoice { .. })
    ));
}

#[test]
fn rejects_keys_that_are_not_account_xpubs_without_echoing_them() {
    let scenario = Scenario::blinded();
    let built = scenario.build();
    let master_xpub = Xpub::from_priv(&scenario.wallet.secp, &scenario.wallet.master).to_string();
    let master_xprv = scenario.wallet.master.to_string();
    for bad in [master_xpub, master_xprv] {
        let mut request = scenario.request(&built.psbt, &built.fascia);
        request.accounts.account_xpub_colored.clone_from(&bad);
        let error = verify_rgb_send(request).unwrap_err();
        assert!(matches!(error, VerifierError::InvalidArgument { .. }));
        assert!(!error.to_string().contains(&bad));
    }
    let mut request = scenario.request(&built.psbt, &built.fascia);
    request.accounts.master_fingerprint = "zzzzzzzz".into();
    assert!(matches!(
        verify_rgb_send(request),
        Err(VerifierError::InvalidArgument { .. })
    ));
}

#[test]
fn rejects_malformed_blobs() {
    let scenario = Scenario::blinded();
    let built = scenario.build();
    let mut request = scenario.request(&built.psbt, &built.fascia);
    request.fascia.push(0);
    assert!(matches!(
        verify_rgb_send(request),
        Err(VerifierError::InvalidFascia { .. })
    ));
    let mut request = scenario.request(&built.psbt, &built.fascia);
    request.psbt_base64.push('\n');
    assert!(matches!(
        verify_rgb_send(request),
        Err(VerifierError::InvalidPsbt { .. })
    ));
}

// --- Key derivation and a real gateway preparation ------------------------

#[test]
fn account_xpubs_re_derive_the_wallets_own_keys() {
    let wallet = TestWallet::new();
    assert_eq!(wallet.fingerprint.to_string(), "73c5da0a");
    let accounts = Accounts::parse(NETWORK, &wallet.accounts(), 10).unwrap();
    for account in [AccountKind::Vanilla, AccountKind::Colored] {
        let (key, script) = accounts.derive(account, 3).unwrap();
        assert_eq!(key, wallet.key(account, 3));
        assert_eq!(script, wallet.script(account, 3));
    }
    assert!(accounts.derive(AccountKind::Colored, 11).is_err());
}

/// `gateway-rgb-pr174.psbt` is an RGB send rgb-lib prepared behind the regtest
/// gateway for the same public test mnemonic (provenance in
/// `tests/fixtures/README.md`). Its fascia was not retained, so this checks
/// what does not need one: the commitment sits where rgb-lib puts it, and every
/// other output re-derives from the account xpubs.
#[test]
fn reads_a_real_gateway_preparation() {
    let wallet = TestWallet::new();
    let psbt = crate::psbt::decode_psbt(GATEWAY_RGB_PSBT.trim()).unwrap();
    assert_eq!(
        psbt.unsigned_tx.compute_txid().to_string(),
        "e41e4ebdc769b0575126a5d728394d4c01206110e7eaebf6446029d5acd0d814"
    );
    let (opret_vout, _) = crate::psbt::opret_commitment(&psbt.unsigned_tx).unwrap();
    let accounts = Accounts::parse(NETWORK, &wallet.accounts(), 10_000).unwrap();
    let mut owned = Vec::new();
    for (vout, (txout, output)) in psbt
        .unsigned_tx
        .output
        .iter()
        .zip(&psbt.outputs)
        .enumerate()
    {
        if vout != opret_vout {
            owned.push(
                accounts
                    .classify_output(vout, output, txout)
                    .unwrap()
                    .unwrap(),
            );
        }
    }
    assert!(!owned.is_empty());
    assert!(
        owned
            .iter()
            .any(|output| output.account == AccountKind::Colored)
    );
}

// --- Cross-language smoke fixture ----------------------------------------

const FFI_SMOKE_PATH: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/ffi-smoke.json");

/// A valid blinded send, for binding smoke tests in Python, Kotlin and Swift.
/// `mpcEntropy` is a decimal string because it exceeds 2^53.
fn ffi_smoke_fixture() -> serde_json::Value {
    let scenario = Scenario::blinded();
    let built = scenario.build();
    let request = scenario.request(&built.psbt, &built.fascia);
    let verdict = verify_rgb_send(request.clone()).unwrap();
    serde_json::json!({
        "description": "Synthetic blinded RGB send built with psrgbt::rgb_commit for the public \
                        'abandon ... about' test mnemonic on regtest. Never fund it.",
        "network": "Regtest",
        "masterFingerprint": request.accounts.master_fingerprint,
        "accountXpubVanilla": request.accounts.account_xpub_vanilla,
        "accountXpubColored": request.accounts.account_xpub_colored,
        "psbtBase64": request.psbt_base64,
        "fasciaHex": hex::encode(&request.fascia),
        "mpcEntropy": request.mpc_entropy.to_string(),
        "invoice": request.invoice,
        "assetId": request.asset_id,
        "amount": request.amount,
        "maxDerivationIndex": request.max_derivation_index,
        "expected": {
            "txid": verdict.txid,
            "recipientAmount": verdict.recipient.amount,
            "retainedAmount": 90,
            "retainedVout": 1,
        },
    })
}

#[test]
fn ffi_smoke_fixture_is_current() {
    let committed: serde_json::Value =
        serde_json::from_str(&std::fs::read_to_string(FFI_SMOKE_PATH).unwrap()).unwrap();
    assert_eq!(
        committed,
        ffi_smoke_fixture(),
        "regenerate with `cargo test write_ffi_smoke_fixture -- --ignored`"
    );
}

#[test]
#[ignore = "rewrites tests/fixtures/ffi-smoke.json"]
fn write_ffi_smoke_fixture() {
    let json = serde_json::to_string_pretty(&ffi_smoke_fixture()).unwrap();
    std::fs::write(FFI_SMOKE_PATH, json + "\n").unwrap();
}
