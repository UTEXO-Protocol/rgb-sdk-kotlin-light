use thiserror::Error;

/// Stable failure categories crossing the native-language boundary.
///
/// Every variant means "do not sign". Messages are deliberately safe to
/// surface: they name output indexes, counts and asset ids only, and never
/// include keys, PSBTs, fascia bytes, invoices or other caller-supplied values.
#[derive(Debug, Error, uniffi::Error)]
pub enum VerifierError {
    #[error("invalid argument: {reason}")]
    InvalidArgument { reason: String },

    #[error("invalid PSBT: {reason}")]
    InvalidPsbt { reason: String },

    #[error("invalid fascia: {reason}")]
    InvalidFascia { reason: String },

    #[error("invalid RGB invoice: {reason}")]
    InvalidRgbInvoice { reason: String },

    #[error("RGB verification rejected the transaction: {reason}")]
    Rejected { reason: String },
}

pub(crate) type Result<T> = std::result::Result<T, VerifierError>;

pub(crate) fn invalid_argument(reason: impl Into<String>) -> VerifierError {
    VerifierError::InvalidArgument {
        reason: reason.into(),
    }
}

pub(crate) fn invalid_psbt(reason: impl Into<String>) -> VerifierError {
    VerifierError::InvalidPsbt {
        reason: reason.into(),
    }
}

pub(crate) fn invalid_fascia(reason: impl Into<String>) -> VerifierError {
    VerifierError::InvalidFascia {
        reason: reason.into(),
    }
}

pub(crate) fn invalid_rgb_invoice(reason: impl Into<String>) -> VerifierError {
    VerifierError::InvalidRgbInvoice {
        reason: reason.into(),
    }
}

pub(crate) fn rejected(reason: impl Into<String>) -> VerifierError {
    VerifierError::Rejected {
        reason: reason.into(),
    }
}
