use std::str::FromStr;

use bitcoin::bip32::{ChildNumber, DerivationPath, Fingerprint, Xpub};
use bitcoin::psbt::Output as PsbtOutput;
use bitcoin::secp256k1::{Secp256k1, VerifyOnly, XOnlyPublicKey};
use bitcoin::{Script, ScriptBuf, Transaction, TxOut, Txid};

use crate::error::{Result, invalid_argument, rejected};
use crate::model::{
    ACCOUNT_ZERO, AccountKind, ExistingOutputProof, KEYCHAIN_BRANCH, Network, PURPOSE_BIP86,
    WalletAccounts,
};

/// Largest serialized transaction accepted in an existing-output proof.
const MAX_PROOF_TRANSACTION_BYTES: usize = 4_000_000;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct OwnedOutput {
    pub account: AccountKind,
    pub index: u32,
}

/// The wallet's account keys. Every ownership claim is checked by re-deriving
/// the script from these keys; PSBT metadata only says which key to try.
pub(crate) struct Accounts {
    network: Network,
    fingerprint: Fingerprint,
    vanilla: Xpub,
    colored: Xpub,
    max_index: u32,
    secp: Secp256k1<VerifyOnly>,
}

impl Accounts {
    pub(crate) fn parse(
        network: Network,
        accounts: &WalletAccounts,
        max_index: u32,
    ) -> Result<Self> {
        let fingerprint = parse_fingerprint(&accounts.master_fingerprint)?;
        let vanilla = parse_account_xpub(network, &accounts.account_xpub_vanilla, "vanilla")?;
        let colored = parse_account_xpub(network, &accounts.account_xpub_colored, "colored")?;
        if vanilla.public_key == colored.public_key {
            return Err(invalid_argument(
                "vanilla and colored account xpubs must differ",
            ));
        }
        Ok(Self {
            network,
            fingerprint,
            vanilla,
            colored,
            max_index,
            secp: Secp256k1::verification_only(),
        })
    }

    pub(crate) fn derive(
        &self,
        account: AccountKind,
        index: u32,
    ) -> Result<(XOnlyPublicKey, ScriptBuf)> {
        if index > self.max_index {
            return Err(rejected("derivation index exceeds the accepted maximum"));
        }
        let path = [
            ChildNumber::from_normal_idx(KEYCHAIN_BRANCH)
                .map_err(|_| invalid_argument("invalid derivation branch"))?,
            ChildNumber::from_normal_idx(index)
                .map_err(|_| rejected("derivation index is not a normal child"))?,
        ];
        let xpub = match account {
            AccountKind::Vanilla => &self.vanilla,
            AccountKind::Colored => &self.colored,
        };
        let child = xpub
            .derive_pub(&self.secp, &path)
            .map_err(|_| invalid_argument("key derivation failed"))?;
        let key = child.to_x_only_pub();
        Ok((key, ScriptBuf::new_p2tr(&self.secp, key, None)))
    }

    /// Classifies one PSBT output.
    ///
    /// `Ok(None)` means the output makes no claim to belong to this wallet.
    /// An output whose metadata names this wallet's master fingerprint must
    /// prove it in full, or the whole transaction is rejected: a false claim
    /// is never downgraded to "foreign".
    pub(crate) fn classify_output(
        &self,
        vout: usize,
        output: &PsbtOutput,
        txout: &TxOut,
    ) -> Result<Option<OwnedOutput>> {
        let claims_ours = output
            .tap_key_origins
            .values()
            .any(|(_, (fingerprint, _))| *fingerprint == self.fingerprint)
            || output
                .bip32_derivation
                .values()
                .any(|(fingerprint, _)| *fingerprint == self.fingerprint);
        if !claims_ours {
            return Ok(None);
        }
        if !txout.script_pubkey.is_p2tr()
            || output.redeem_script.is_some()
            || output.witness_script.is_some()
            || !output.bip32_derivation.is_empty()
            || output.tap_tree.is_some()
            || output.tap_key_origins.len() != 1
        {
            return Err(rejected(format!(
                "output {vout} claims this wallet but is not a BIP86 key-path output"
            )));
        }
        let internal_key = output.tap_internal_key.ok_or_else(|| {
            rejected(format!(
                "output {vout} claims this wallet without an internal key"
            ))
        })?;
        let (origin_key, (leaves, (_, path))) = output
            .tap_key_origins
            .iter()
            .next()
            .ok_or_else(|| rejected(format!("output {vout} key origin is missing")))?;
        if !leaves.is_empty() || *origin_key != internal_key {
            return Err(rejected(format!(
                "output {vout} carries a script-path origin"
            )));
        }
        let owned = self.parse_owned_path(path)?;
        let (expected_key, expected_script) = self.derive(owned.account, owned.index)?;
        if expected_key != internal_key || expected_script != txout.script_pubkey {
            return Err(rejected(format!(
                "output {vout} does not re-derive from this wallet's keys"
            )));
        }
        Ok(Some(owned))
    }

    /// Proves `proof` is the colored-account output `txid:vout`, returning its
    /// derivation index.
    pub(crate) fn prove_existing_output(&self, proof: &ExistingOutputProof) -> Result<(Txid, u32)> {
        if proof.transaction.len() > MAX_PROOF_TRANSACTION_BYTES {
            return Err(invalid_argument(
                "existing-output proof transaction exceeds the size limit",
            ));
        }
        let transaction: Transaction = bitcoin::consensus::deserialize(&proof.transaction)
            .map_err(|_| invalid_argument("existing-output proof transaction does not parse"))?;
        let txout = usize::try_from(proof.vout)
            .ok()
            .and_then(|vout| transaction.output.get(vout))
            .ok_or_else(|| invalid_argument("existing-output proof vout is out of range"))?;
        self.require_colored_script(&txout.script_pubkey, proof.derivation_index)?;
        Ok((transaction.compute_txid(), proof.derivation_index))
    }

    fn require_colored_script(&self, script: &Script, index: u32) -> Result<()> {
        let (_, expected) = self.derive(AccountKind::Colored, index)?;
        if expected.as_script() != script {
            return Err(rejected(
                "existing output does not re-derive from this wallet's colored account",
            ));
        }
        Ok(())
    }

    fn parse_owned_path(&self, path: &DerivationPath) -> Result<OwnedOutput> {
        let children: Vec<ChildNumber> = path.into_iter().copied().collect();
        let [purpose, coin, account, branch, index] = children.as_slice() else {
            return Err(rejected("derivation path must contain exactly five levels"));
        };
        let (
            ChildNumber::Hardened { index: purpose },
            ChildNumber::Hardened { index: coin },
            ChildNumber::Hardened { index: account },
            ChildNumber::Normal { index: branch },
            ChildNumber::Normal { index },
        ) = (*purpose, *coin, *account, *branch, *index)
        else {
            return Err(rejected(
                "derivation path hardening is outside the BIP86 profile",
            ));
        };
        if purpose != PURPOSE_BIP86 || account != ACCOUNT_ZERO || branch != KEYCHAIN_BRANCH {
            return Err(rejected(
                "derivation path is outside the rgb-lib BIP86 profile",
            ));
        }
        let account = if coin == self.network.coin_type(AccountKind::Vanilla) {
            AccountKind::Vanilla
        } else if coin == self.network.coin_type(AccountKind::Colored) {
            AccountKind::Colored
        } else {
            return Err(rejected(
                "derivation coin type is outside this network's profile",
            ));
        };
        Ok(OwnedOutput { account, index })
    }
}

fn parse_fingerprint(value: &str) -> Result<Fingerprint> {
    if value.len() != 8 || !value.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        return Err(invalid_argument(
            "master fingerprint must be 8 hex characters",
        ));
    }
    Fingerprint::from_str(value).map_err(|_| invalid_argument("master fingerprint is invalid"))
}

fn parse_account_xpub(network: Network, value: &str, label: &str) -> Result<Xpub> {
    let xpub = Xpub::from_str(value)
        .map_err(|_| invalid_argument(format!("{label} account xpub is invalid")))?;
    if xpub.network != network.network_kind() {
        return Err(invalid_argument(format!(
            "{label} account xpub is for another network"
        )));
    }
    let account = ChildNumber::Hardened {
        index: ACCOUNT_ZERO,
    };
    if xpub.depth != 3 || xpub.child_number != account {
        return Err(invalid_argument(format!(
            "{label} account xpub is not an m/86'/coin'/0' account key"
        )));
    }
    Ok(xpub)
}
