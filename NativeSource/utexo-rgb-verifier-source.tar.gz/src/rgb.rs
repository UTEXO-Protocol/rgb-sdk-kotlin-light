use std::collections::{BTreeMap, BTreeSet};

use amplify::ByteArray;
use amplify::confinement::{Confined, U32};
use rgbcore::commit_verify::mpc::{
    MPC_MINIMAL_DEPTH, MerkleTree, Message, MessageMap, MultiSource, ProtocolId,
};
use rgbcore::commit_verify::{CommitId, TryCommitVerify};
use rgbcore::{ContractId, OpId, Operation, Transition};
use rgbstd::containers::Fascia;
use strict_encoding::StrictDeserialize;

use crate::error::{Result, invalid_argument, invalid_fascia, rejected};

pub(crate) const MAX_FASCIA_BYTES: usize = 16 * 1024 * 1024;

/// A transition the signature authorizes, proven to hash to the id its
/// bundle commits to.
pub(crate) struct Disclosed<'a> {
    pub contract: ContractId,
    pub opid: OpId,
    pub transition: &'a Transition,
}

/// Decodes the fascia exactly as rgb-lib writes it (`write_fascia`).
pub(crate) fn decode_fascia(bytes: &[u8]) -> Result<Fascia> {
    if bytes.is_empty() {
        return Err(invalid_argument("fascia must not be empty"));
    }
    if bytes.len() > MAX_FASCIA_BYTES {
        return Err(invalid_fascia("fascia exceeds the size limit"));
    }
    let data = Confined::<Vec<u8>, 0, U32>::try_from(bytes.to_vec())
        .map_err(|_| invalid_fascia("fascia exceeds the size limit"))?;
    Fascia::from_strict_serialized::<U32>(data)
        .map_err(|_| invalid_fascia("strict decoding failed"))
}

/// Rebuilds the MPC commitment from every bundle in the fascia.
///
/// With the tree's entropy the construction is deterministic, so a match with
/// the transaction's opret proves the fascia lists every committed contract:
/// one hidden bundle would change the root.
pub(crate) fn recompute_commitment(fascia: &Fascia, entropy: u64) -> Result<[u8; 32]> {
    let messages: BTreeMap<ProtocolId, Message> = fascia
        .bundles()
        .iter()
        .map(|(contract, bundle)| {
            (
                ProtocolId::from(*contract),
                Message::from(bundle.bundle_id()),
            )
        })
        .collect();
    let messages = MessageMap::try_from(messages)
        .map_err(|_| invalid_fascia("fascia commits to too many contracts"))?;
    let source = MultiSource {
        min_depth: MPC_MINIMAL_DEPTH,
        messages,
        static_entropy: Some(entropy),
    };
    let tree = MerkleTree::try_commit(&source)
        .map_err(|_| rejected("no MPC tree exists for the committed contracts and entropy"))?;
    Ok(tree.commit_id().to_byte_array())
}

/// Every transition the transaction's signature authorizes.
///
/// A bundle id commits only to the bundle's input map (opout → opid), and an
/// opid is the hash of its transition. So once the commitment is matched,
/// requiring every input-map opid to be disclosed, hash-checked and to consume
/// exactly the opouts mapped to it leaves no transition the client can't see.
pub(crate) fn disclosed_transitions(fascia: &Fascia) -> Result<Vec<Disclosed<'_>>> {
    let mut all = Vec::new();
    for (contract, bundle) in fascia.bundles() {
        let mut by_opid = BTreeMap::<OpId, &Transition>::new();
        for known in &bundle.known_transitions {
            let opid = known.transition.id();
            if known.opid != opid {
                return Err(rejected(format!(
                    "a transition of {contract} does not hash to its disclosed id"
                )));
            }
            if known.transition.contract_id != *contract {
                return Err(rejected(format!(
                    "a transition bundled under {contract} belongs to another contract"
                )));
            }
            if by_opid.insert(opid, &known.transition).is_some() {
                return Err(rejected(format!(
                    "a transition of {contract} is disclosed twice"
                )));
            }
        }
        let mapped: BTreeSet<OpId> = bundle.input_map.values().copied().collect();
        for (opout, opid) in &bundle.input_map {
            let transition = by_opid.get(opid).ok_or_else(|| {
                rejected(format!(
                    "the bundle of {contract} commits to a transition it does not disclose"
                ))
            })?;
            if !transition.inputs().contains(opout) {
                return Err(rejected(format!(
                    "the bundle of {contract} maps an input to a transition that does not spend it"
                )));
            }
        }
        for (opid, transition) in &by_opid {
            if !mapped.contains(opid) {
                return Err(rejected(format!(
                    "the bundle of {contract} discloses a transition it does not commit to"
                )));
            }
            for opout in transition.inputs() {
                if bundle.input_map.get(&opout) != Some(opid) {
                    return Err(rejected(format!(
                        "a transition of {contract} spends an input its bundle maps elsewhere"
                    )));
                }
            }
            all.push(Disclosed {
                contract: *contract,
                opid: *opid,
                transition,
            });
        }
    }
    Ok(all)
}
