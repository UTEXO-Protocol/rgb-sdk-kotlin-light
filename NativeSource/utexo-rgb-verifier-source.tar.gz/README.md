# utexo-rgb-verifier

Pre-sign RGB verification for the UTEXO mobile SDKs: one Rust core with UniFFI
bindings for Kotlin and Swift.

The gateway prepares RGB sends and the device signs them. Spending a colored
input authorizes whatever RGB transition the transaction commits to, and that
commitment is opaque to the local signer, whose README says so directly:
"Bitcoin validation cannot prove RGB transition semantics". So a compromised
backend can send the payment and the wallet's own RGB change to seals it
controls while the PSBT passes every bitcoin check. This crate closes that hole.
The background is in `rln-gateway/docs/design/rgb-client-side-verification.md`.

## What `verify_rgb_send` proves

It takes the unsigned PSBT, rgb-lib's fascia and MPC entropy, the invoice, the
user-approved asset and amount, and the wallet's account xpubs. It returns a
verdict only if all of these hold:

1. **The fascia describes this transaction.** Its witness txid equals the PSBT's
   unsigned txid, and its commitment method is opret.
2. **No committed contract is hidden.** The transaction's single `OP_RETURN`
   carries 32 bytes equal to the MPC root recomputed from every bundle in the
   fascia with the given entropy (`src/rgb.rs`, `recompute_commitment`).
3. **No committed transition is hidden.** A bundle id commits only to its input
   map, so every opid in it must be disclosed, must hash to that id, and must
   spend exactly the inputs mapped to it (`disclosed_transitions`).
4. **There is no second commitment.** Every output is the `OP_RETURN`, a wallet
   output whose script re-derives from the account xpubs, or, for a witness
   invoice, the single output paying the invoice's script. None of these can
   carry a tapret commitment.
5. **The beneficiary gets exactly what was approved.** Exactly one assignment
   goes to the invoice's beneficiary (its blinded seal, or the witness output),
   for the approved asset and amount.
6. **Everything else comes back.** Every other assignment of every committed
   transition (RGB change, other assets on spent inputs, rights) goes to a
   revealed seal on the wallet's colored account. That is either an output of
   this transaction or an existing UTXO whose creating transaction was supplied
   and re-derives.

So the signature cannot move RGB state to anyone except the invoice's
beneficiary and the wallet.

## What it does not prove

- **That the transitions are valid RGB history**, such as amount conservation
  or schema rules. An invalid transition destroys the state it spends; nobody
  gains it.
- **That the fascia covers every allocation on the spent inputs.** Proving an
  absence needs the wallet's own RGB state, which a stateless client doesn't
  hold. An allocation left out is destroyed when its input is spent.
- **That an existing-UTXO seal is still unspent.** That needs an indexer, and a
  spent one destroys the change assigned to it.
- **Bitcoin policy**: input ownership, fees, the witness output's sats,
  locktime. The local signer checks these, so run both.
- **Invoice expiry and transport endpoints**, which the SDK facades check
  already.

Each gap destroys value rather than redirecting it. The server holds the user's
only copy of their RGB history today, so it can already destroy assets by
deleting that history.

## Inputs

| Field | Source | Trusted |
| --- | --- | --- |
| `network`, `accounts` | the device's own key derivation (the signer's `WalletIdentity`) | yes |
| `invoice`, `asset_id`, `amount` | what the user entered and approved, never the gateway's echo of it | yes |
| `psbt_base64` | gateway prepare response | no |
| `fascia`, `mpc_entropy` | rgb-lib `send_begin`: the bytes at `details.fascia_path`, and `details.entropy` | no |
| `existing_output_proofs` | the raw transaction of each existing UTXO used as a seal, plus its derivation index | no, self-authenticating |
| `max_derivation_index` | SDK policy; `10_000` matches `verify.ts` | yes |

rgb-lib uses an existing UTXO for RGB change when the send has no BTC change
output (`get_change_seal` in rgb-lib-bfa `src/wallet/online.rs`). Otherwise
`existing_output_proofs` is empty.

## Server changes this needs

rgb-node-api's `sendbegin` currently forwards only `val.psbt` (`src/wallet/wallet_thread.rs`).
To feed the verifier it must also return:

- the fascia file bytes and `details.entropy`;
- for every concrete-outpoint seal, the transaction that created that UTXO and
  its index on the colored account.

The gateway then passes these through in the send-asset prepare response. They
are new fields, so the response contract doesn't break. They describe only the
requesting user's own transfer.

The Kotlin SDK reads them from an optional `rgbEvidence` object next to `psbt`.
It must contain exactly these keys:

```json
"rgbEvidence": {
  "fascia": "<canonical padded Base64 of the strict-encoded fascia>",
  "mpcEntropy": "<details.entropy as decimal text: a u64 exceeds JSON's safe integers>",
  "existingOutputProofs": [
    { "transaction": "<lowercase hex of the creating transaction>", "vout": 1, "derivationIndex": 7 }
  ]
}
```

`existingOutputProofs` is empty unless a seal is an existing UTXO, and holds at
most 8 proofs. A missing or `null` `rgbEvidence` means the gateway sent no
evidence. The SDK then refuses to sign unless its policy explicitly allows
unverified RGB sends.

## Using it from the SDKs

Call it after binding the gateway's intent to the user's request, and before
the signer. Sign only if it returns a verdict.

```kotlin
import com.utexo.rgb.sdk.internal.ffi.verifier.*

val verdict = verifyRgbSend(
    RgbSendRequest(
        network = Network.REGTEST,
        accounts = WalletAccounts(
            masterFingerprint = identity.masterFingerprint,
            accountXpubVanilla = identity.accountXpubVanilla,
            accountXpubColored = identity.accountXpubColored,
        ),
        psbtBase64 = prepared.psbt,
        fascia = prepared.fascia,
        mpcEntropy = prepared.mpcEntropy,
        invoice = request.invoice,
        assetId = request.assetId,
        amount = request.amount,
        existingOutputProofs = prepared.existingOutputProofs,
        maxDerivationIndex = 10_000u,
    ),
) // throws VerifierException: do not sign; its message is safe to log
```

```swift
let verdict = try verifyRgbSend(request: RgbSendRequest(
    network: .regtest,
    accounts: WalletAccounts(
        masterFingerprint: identity.masterFingerprint,
        accountXpubVanilla: identity.accountXpubVanilla,
        accountXpubColored: identity.accountXpubColored),
    psbtBase64: prepared.psbt,
    fascia: prepared.fascia,
    mpcEntropy: prepared.mpcEntropy,
    invoice: request.invoice,
    assetId: request.assetId,
    amount: request.amount,
    existingOutputProofs: prepared.existingOutputProofs,
    maxDerivationIndex: 10_000)) // throws VerifierError
```

`network` uses the signer's `Network` variants, including `Utexo`. Error
messages name output indexes, counts and asset ids only. They never include
keys, PSBTs, fascia bytes or invoices.

## Building

```sh
cargo test --locked             # unit and attack tests
scripts/ffi-smoke.sh            # calls the built library through generated Python bindings
scripts/generate-bindings.sh    # Kotlin and Swift bindings into target/bindings
scripts/build-android.sh        # release .so per ABI into target/android/jniLibs
```

The tests build every PSBT and fascia with `psrgbt::rgb_commit`, the code
rgb-lib's `send_begin` runs. Each attack test then changes one thing a hostile
preparer controls. `tests/fixtures/README.md` covers the fixtures, including
one real gateway preparation.

On Android release builds (`opt-level = "z"`, stripped), `libutexo_rgb_verifier.so`
is 3.1 MB on arm64-v8a, 2.1 MB on armeabi-v7a and 3.2 MB on x86_64, against
2.4 MB, 2.0 MB and 2.6 MB for `libutexo_local_signer.so`.

The RGB crates are pinned to the exact versions rgb-node-api resolves through
rgb-lib-bfa `v0.3.0-beta.7-upstream-dev-bfa.3` (`rgb-consensus`, `rgb-ops`,
`rgb-invoicing` `0.11.2-rc.1`; `bitcoin 0.32.102`). Bump them together with
rgb-node-api: ids and commitments must come from the same code on both sides.

## Packaging

Shipping this as a second Rust library next to `utexo-local-signer` works on
Android but costs a second copy of std, `bitcoin` and `secp256k1`. On iOS, two
Rust static libraries in one app typically collide on duplicate symbols, and
the usual UniFFI practice is one combined library per app. The intended path is
to add this crate as a path dependency of `utexo-local-signer` and generate both
crates' bindings from the signer's library. The signer's `uniffi-bindgen.toml`
already uses the per-crate format, so that is one more
`[crates.utexo_rgb_verifier.*]` section plus a `crate-roots` entry.

## Status

- Not yet run against a fascia that rgb-lib-bfa itself wrote. The fixtures use
  `psrgbt` 0.11.2-rc.1, the commit code rgb-lib-bfa calls, but a capture from
  the regtest stack should become a fixture once rgb-node-api returns the
  fascia and entropy.
- iOS libraries and the Swift bindings are generated but haven't been compiled;
  this was developed on Linux.
- Built with rustc 1.98.0. The signer pins 1.88.0, which hasn't been tried.
